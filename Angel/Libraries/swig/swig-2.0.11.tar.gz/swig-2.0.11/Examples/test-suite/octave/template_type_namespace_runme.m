template_type_namespace

assert(strcmp(foo()(1),"foo"));

                                  
