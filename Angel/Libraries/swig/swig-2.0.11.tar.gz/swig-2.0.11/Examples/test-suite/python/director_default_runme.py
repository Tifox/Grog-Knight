from director_default import *


f = Foo()
f = Foo(1)


f = Bar()
f = Bar(1)
