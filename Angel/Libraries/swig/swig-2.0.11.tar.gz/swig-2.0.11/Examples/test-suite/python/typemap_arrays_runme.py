from typemap_arrays import *

if sumA(None) != 60:
    raise RuntimeError, "Sum is wrong"

