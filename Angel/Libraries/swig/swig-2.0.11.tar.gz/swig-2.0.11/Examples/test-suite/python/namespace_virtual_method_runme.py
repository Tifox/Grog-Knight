import namespace_virtual_method

x = namespace_virtual_method.Spam()
