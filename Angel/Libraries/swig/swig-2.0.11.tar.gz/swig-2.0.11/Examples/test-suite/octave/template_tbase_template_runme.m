template_tbase_template

a = make_Class_dd();
if (!strcmp(a.test(),"test"))
  error
endif
