from li_std_vector_ptr import *

ip1 = makeIntPtr(11)
ip2 = makeIntPtr(22)

vi = IntPtrVector((ip1, ip2))
displayVector(vi)

